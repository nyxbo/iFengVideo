$(function(){
	var resend = false;
	//验证手机号是否符合领流量条件
	function checkMobile(){
	var mobile = $('#mobile').val();
		if(!mobile){
			alert("请填写手机号");
		}else if(!(/^1[34578]\d{9}$/.test(mobile))){
			alert("手机号格式有误, 请重新输入");
			$('#mobile').text('');
		}else{
			$.ajax({
				type: "post",
				url: "https://user.iclient.ifeng.com/Active_Cellnetwork/getCaptcha?phone=" + mobile,
				dataType: "jsonp",
				success: function(data){
					if (data.code) {
						if (data.code != 200){
							alert("该活动仅限特定用户参与，请确认手机号码是否正确");
						}
					}else{
						showTimer();
					}
				}
			})		
		}	
	}
	//x秒后重新发送
	function showTimer(){
		clearInterval(timer);
		$('#reSendCode').hide()
	    $('#waitResend').show().find('#time').text(60);
	    var timer = setInterval(function(){
	    	if(parseInt($("#time").text()) == 0){
	    		clearInterval(timer);
	    		resend = false;
	    		$('#waitResend').hide();
	    		$('#reSendCode').show();
	    	}
	    	resend = true;
	    	$('#time').text(parseInt($('#time').text()) - 1);
	    },1000);

	}
	//验证验证码
	function checkCode(){
		var mobile = $('#mobile').val();
		var captcha = $('#codeNum').val();
		if(!mobile){
			alert("请输入手机号");
		}else if(!captcha){
			alert("请输入验证码");
		}
		$.ajax({
			type: "post",
			url: "https://user.iclient.ifeng.com/Active_Cellnetwork/checkCaptcha?phone=" + mobile + "&captcha=" + captcha,
			dataType: "jsonp",
			success: function(data){
				if(data.code != 200){
					alert("验证码错误");
				}else{
					//第一屏隐藏，第二屏显示，改这里的id名字即可
					$('#first').hide();
					$('#next').show();
				}
			}
		})
	}
	function Continue(){
		//拉起客户端
	}

	if($.cookie('validity') && $.cookie('validity') == "true"){
		$('.content').hide();
	}
	//<script type="text/javascript" src="js/jquery.cookie.js"></script> 
	//设cookie，一天之内不弹出
	$('#exit').click(function(){
		$.cookie("validity","true",{expires: 1});
	})
	if(!resend){
		$('#reSendCode').click(checkMobile());
	}
	$('.receive').click(checkCode());
	$('.receive-again').click(Continue());


	


})